﻿namespace WinFormProductoPDV
{
    partial class FmrLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FmrLogin));
            this.textousuario = new System.Windows.Forms.Label();
            this.textopassword = new System.Windows.Forms.Label();
            this.Usuariologin = new System.Windows.Forms.TextBox();
            this.Passwordlogin = new System.Windows.Forms.TextBox();
            this.btnAceptar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textousuario
            // 
            this.textousuario.AutoSize = true;
            this.textousuario.BackColor = System.Drawing.Color.Transparent;
            this.textousuario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.textousuario.Font = new System.Drawing.Font("Lucida Sans", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textousuario.Location = new System.Drawing.Point(62, 74);
            this.textousuario.Name = "textousuario";
            this.textousuario.Size = new System.Drawing.Size(48, 14);
            this.textousuario.TabIndex = 0;
            this.textousuario.Text = "Usuario";
            // 
            // textopassword
            // 
            this.textopassword.AutoSize = true;
            this.textopassword.BackColor = System.Drawing.Color.Transparent;
            this.textopassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.textopassword.Font = new System.Drawing.Font("Lucida Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.textopassword.Location = new System.Drawing.Point(42, 213);
            this.textopassword.Name = "textopassword";
            this.textopassword.Size = new System.Drawing.Size(73, 15);
            this.textopassword.TabIndex = 1;
            this.textopassword.Text = "Contraseña";
            // 
            // Usuariologin
            // 
            this.Usuariologin.Location = new System.Drawing.Point(144, 74);
            this.Usuariologin.Name = "Usuariologin";
            this.Usuariologin.Size = new System.Drawing.Size(318, 23);
            this.Usuariologin.TabIndex = 2;
            this.Usuariologin.TextChanged += new System.EventHandler(this.Usuariologin_TextChanged);
            // 
            // Passwordlogin
            // 
            this.Passwordlogin.Location = new System.Drawing.Point(144, 213);
            this.Passwordlogin.Name = "Passwordlogin";
            this.Passwordlogin.PasswordChar = '*';
            this.Passwordlogin.Size = new System.Drawing.Size(318, 23);
            this.Passwordlogin.TabIndex = 3;
            this.Passwordlogin.TextChanged += new System.EventHandler(this.Passwordlogin_TextChanged);
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(213, 267);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(75, 23);
            this.btnAceptar.TabIndex = 4;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Lucida Sans Typewriter", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(236, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(133, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ingrese Su Usuario";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Font = new System.Drawing.Font("Lucida Sans", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label2.Location = new System.Drawing.Point(236, 195);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(119, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Ingrese Contraseña";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(306, 267);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Cancelar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FmrLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aquamarine;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(584, 361);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnAceptar);
            this.Controls.Add(this.Passwordlogin);
            this.Controls.Add(this.Usuariologin);
            this.Controls.Add(this.textopassword);
            this.Controls.Add(this.textousuario);
            this.Name = "FmrLogin";
            this.Text = "Login";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label textousuario;
        private Label textopassword;
        private TextBox Usuariologin;
        private TextBox Passwordlogin;
        private Button btnAceptar;
        private Label label1;
        private Label label2;
        private Button button1;
    }
}