﻿namespace WinFormProductoPDV
{
    partial class FrmUsuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUsuarios));
            this.panelPpal = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dGridUsuarios = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Correo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBoxBuscar = new System.Windows.Forms.PictureBox();
            this.pictureBoxEliminar = new System.Windows.Forms.PictureBox();
            this.pictureBoxGuardar = new System.Windows.Forms.PictureBox();
            this.pictureBoxEditar = new System.Windows.Forms.PictureBox();
            this.pictureBoxAgregar = new System.Windows.Forms.PictureBox();
            this.lblConfirmaContra = new System.Windows.Forms.Label();
            this.txtConfirmaContra = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblImagen = new System.Windows.Forms.Label();
            this.txtImagen = new System.Windows.Forms.TextBox();
            this.lblCorreo = new System.Windows.Forms.Label();
            this.txtCorreo = new System.Windows.Forms.TextBox();
            this.lblNombre = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.txtBuscador = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panelPpal.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dGridUsuarios)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEliminar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGuardar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEditar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAgregar)).BeginInit();
            this.SuspendLayout();
            // 
            // panelPpal
            // 
            this.panelPpal.BackColor = System.Drawing.Color.Transparent;
            this.panelPpal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelPpal.Controls.Add(this.panel2);
            this.panelPpal.Controls.Add(this.panel1);
            this.panelPpal.Location = new System.Drawing.Point(12, 12);
            this.panelPpal.Name = "panelPpal";
            this.panelPpal.Size = new System.Drawing.Size(1142, 638);
            this.panelPpal.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel2.Controls.Add(this.dGridUsuarios);
            this.panel2.Location = new System.Drawing.Point(15, 409);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1108, 212);
            this.panel2.TabIndex = 1;
            // 
            // dGridUsuarios
            // 
            this.dGridUsuarios.BackgroundColor = System.Drawing.Color.LightSlateGray;
            this.dGridUsuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGridUsuarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Correo,
            this.Column3,
            this.Column6});
            this.dGridUsuarios.Location = new System.Drawing.Point(3, 3);
            this.dGridUsuarios.Name = "dGridUsuarios";
            this.dGridUsuarios.RowTemplate.Height = 25;
            this.dGridUsuarios.Size = new System.Drawing.Size(1098, 426);
            this.dGridUsuarios.TabIndex = 0;
            this.dGridUsuarios.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGridUsuarios_CellClick);
            this.dGridUsuarios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGridUsuarios_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "ID";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Nombre";
            this.Column2.Name = "Column2";
            // 
            // Correo
            // 
            this.Correo.HeaderText = "Correo";
            this.Correo.Name = "Correo";
            this.Correo.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Password";
            this.Column3.Name = "Column3";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "IMagen";
            this.Column6.Name = "Column6";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.pictureBoxBuscar);
            this.panel1.Controls.Add(this.pictureBoxEliminar);
            this.panel1.Controls.Add(this.pictureBoxGuardar);
            this.panel1.Controls.Add(this.pictureBoxEditar);
            this.panel1.Controls.Add(this.pictureBoxAgregar);
            this.panel1.Controls.Add(this.lblConfirmaContra);
            this.panel1.Controls.Add(this.txtConfirmaContra);
            this.panel1.Controls.Add(this.lblPassword);
            this.panel1.Controls.Add(this.txtPassword);
            this.panel1.Controls.Add(this.lblImagen);
            this.panel1.Controls.Add(this.txtImagen);
            this.panel1.Controls.Add(this.lblCorreo);
            this.panel1.Controls.Add(this.txtCorreo);
            this.panel1.Controls.Add(this.lblNombre);
            this.panel1.Controls.Add(this.txtNombre);
            this.panel1.Controls.Add(this.txtBuscador);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.panel1.Location = new System.Drawing.Point(13, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1108, 380);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // pictureBoxBuscar
            // 
            this.pictureBoxBuscar.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxBuscar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxBuscar.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxBuscar.Image")));
            this.pictureBoxBuscar.Location = new System.Drawing.Point(1062, 51);
            this.pictureBoxBuscar.Name = "pictureBoxBuscar";
            this.pictureBoxBuscar.Size = new System.Drawing.Size(41, 39);
            this.pictureBoxBuscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxBuscar.TabIndex = 21;
            this.pictureBoxBuscar.TabStop = false;
            this.pictureBoxBuscar.Click += new System.EventHandler(this.pictureBoxBuscar_Click);
            // 
            // pictureBoxEliminar
            // 
            this.pictureBoxEliminar.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxEliminar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxEliminar.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxEliminar.Image")));
            this.pictureBoxEliminar.Location = new System.Drawing.Point(949, 318);
            this.pictureBoxEliminar.Name = "pictureBoxEliminar";
            this.pictureBoxEliminar.Size = new System.Drawing.Size(40, 41);
            this.pictureBoxEliminar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEliminar.TabIndex = 20;
            this.pictureBoxEliminar.TabStop = false;
            this.pictureBoxEliminar.Click += new System.EventHandler(this.pictureBoxEliminar_Click);
            // 
            // pictureBoxGuardar
            // 
            this.pictureBoxGuardar.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxGuardar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxGuardar.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxGuardar.Image")));
            this.pictureBoxGuardar.Location = new System.Drawing.Point(1015, 318);
            this.pictureBoxGuardar.Name = "pictureBoxGuardar";
            this.pictureBoxGuardar.Size = new System.Drawing.Size(42, 41);
            this.pictureBoxGuardar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxGuardar.TabIndex = 19;
            this.pictureBoxGuardar.TabStop = false;
            this.pictureBoxGuardar.Click += new System.EventHandler(this.pictureBoxGuardar_Click);
            // 
            // pictureBoxEditar
            // 
            this.pictureBoxEditar.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxEditar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxEditar.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxEditar.Image")));
            this.pictureBoxEditar.Location = new System.Drawing.Point(880, 318);
            this.pictureBoxEditar.Name = "pictureBoxEditar";
            this.pictureBoxEditar.Size = new System.Drawing.Size(42, 41);
            this.pictureBoxEditar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxEditar.TabIndex = 18;
            this.pictureBoxEditar.TabStop = false;
            this.pictureBoxEditar.Click += new System.EventHandler(this.pictureBoxEditar_Click);
            // 
            // pictureBoxAgregar
            // 
            this.pictureBoxAgregar.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxAgregar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxAgregar.Image = ((System.Drawing.Image)(resources.GetObject("pictureBoxAgregar.Image")));
            this.pictureBoxAgregar.Location = new System.Drawing.Point(798, 318);
            this.pictureBoxAgregar.Name = "pictureBoxAgregar";
            this.pictureBoxAgregar.Size = new System.Drawing.Size(41, 41);
            this.pictureBoxAgregar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBoxAgregar.TabIndex = 17;
            this.pictureBoxAgregar.TabStop = false;
            this.pictureBoxAgregar.Click += new System.EventHandler(this.pictureBoxAgregar_Click);
            // 
            // lblConfirmaContra
            // 
            this.lblConfirmaContra.AutoSize = true;
            this.lblConfirmaContra.BackColor = System.Drawing.Color.Transparent;
            this.lblConfirmaContra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblConfirmaContra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblConfirmaContra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblConfirmaContra.Location = new System.Drawing.Point(569, 235);
            this.lblConfirmaContra.Name = "lblConfirmaContra";
            this.lblConfirmaContra.Size = new System.Drawing.Size(192, 27);
            this.lblConfirmaContra.TabIndex = 12;
            this.lblConfirmaContra.Text = "Confirma Contra:";
            // 
            // txtConfirmaContra
            // 
            this.txtConfirmaContra.BackColor = System.Drawing.SystemColors.Window;
            this.txtConfirmaContra.Enabled = false;
            this.txtConfirmaContra.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtConfirmaContra.Location = new System.Drawing.Point(798, 228);
            this.txtConfirmaContra.Name = "txtConfirmaContra";
            this.txtConfirmaContra.PasswordChar = '*';
            this.txtConfirmaContra.Size = new System.Drawing.Size(258, 39);
            this.txtConfirmaContra.TabIndex = 11;
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.BackColor = System.Drawing.Color.Transparent;
            this.lblPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblPassword.Location = new System.Drawing.Point(22, 235);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(142, 27);
            this.lblPassword.TabIndex = 10;
            this.lblPassword.Text = "Contraseña:";
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.Window;
            this.txtPassword.Enabled = false;
            this.txtPassword.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtPassword.Location = new System.Drawing.Point(270, 227);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '?';
            this.txtPassword.Size = new System.Drawing.Size(280, 39);
            this.txtPassword.TabIndex = 9;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // lblImagen
            // 
            this.lblImagen.AutoSize = true;
            this.lblImagen.BackColor = System.Drawing.Color.Transparent;
            this.lblImagen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblImagen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblImagen.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblImagen.Location = new System.Drawing.Point(21, 280);
            this.lblImagen.Name = "lblImagen";
            this.lblImagen.Size = new System.Drawing.Size(68, 27);
            this.lblImagen.TabIndex = 8;
            this.lblImagen.Text = "Foto:";
            this.lblImagen.Click += new System.EventHandler(this.lblImagen_Click);
            // 
            // txtImagen
            // 
            this.txtImagen.BackColor = System.Drawing.SystemColors.Window;
            this.txtImagen.Enabled = false;
            this.txtImagen.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtImagen.Location = new System.Drawing.Point(269, 273);
            this.txtImagen.Name = "txtImagen";
            this.txtImagen.Size = new System.Drawing.Size(787, 39);
            this.txtImagen.TabIndex = 7;
            // 
            // lblCorreo
            // 
            this.lblCorreo.AutoSize = true;
            this.lblCorreo.BackColor = System.Drawing.Color.Transparent;
            this.lblCorreo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCorreo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblCorreo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblCorreo.Location = new System.Drawing.Point(22, 192);
            this.lblCorreo.Name = "lblCorreo";
            this.lblCorreo.Size = new System.Drawing.Size(92, 27);
            this.lblCorreo.TabIndex = 6;
            this.lblCorreo.Text = "Correo:";
            // 
            // txtCorreo
            // 
            this.txtCorreo.BackColor = System.Drawing.SystemColors.Window;
            this.txtCorreo.Enabled = false;
            this.txtCorreo.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCorreo.Location = new System.Drawing.Point(270, 181);
            this.txtCorreo.Name = "txtCorreo";
            this.txtCorreo.Size = new System.Drawing.Size(787, 39);
            this.txtCorreo.TabIndex = 5;
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNombre.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNombre.Location = new System.Drawing.Point(21, 141);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(102, 27);
            this.lblNombre.TabIndex = 4;
            this.lblNombre.Text = "Nombre:";
            // 
            // txtNombre
            // 
            this.txtNombre.BackColor = System.Drawing.SystemColors.Window;
            this.txtNombre.Enabled = false;
            this.txtNombre.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtNombre.Location = new System.Drawing.Point(269, 135);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(787, 39);
            this.txtNombre.TabIndex = 3;
            this.txtNombre.TextChanged += new System.EventHandler(this.txtNombre_TextChanged);
            // 
            // txtBuscador
            // 
            this.txtBuscador.BackColor = System.Drawing.SystemColors.Window;
            this.txtBuscador.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtBuscador.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtBuscador.Location = new System.Drawing.Point(21, 51);
            this.txtBuscador.Name = "txtBuscador";
            this.txtBuscador.Size = new System.Drawing.Size(1035, 39);
            this.txtBuscador.TabIndex = 1;
            this.txtBuscador.TextChanged += new System.EventHandler(this.txtBuscador_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(21, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(195, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Usuario a Buscar";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // FrmUsuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1166, 661);
            this.Controls.Add(this.panelPpal);
            this.Name = "FrmUsuarios";
            this.Text = "FrmUsuarios";
            this.Load += new System.EventHandler(this.FrmUsuarios_Load);
            this.panelPpal.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dGridUsuarios)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxBuscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEliminar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxGuardar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxEditar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxAgregar)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panelPpal;
        private Panel panel2;
        private DataGridView dGridUsuarios;
        private Panel panel1;
        private Label lblConfirmaContra;
        private TextBox txtConfirmaContra;
        private Label lblPassword;
        private TextBox txtPassword;
        private Label lblImagen;
        private TextBox txtImagen;
        private Label lblCorreo;
        private TextBox txtCorreo;
        private Label lblNombre;
        private TextBox txtNombre;
        private TextBox txtBuscador;
        private Label label1;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Correo;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column6;
        private PictureBox pictureBoxAgregar;
        private PictureBox pictureBoxEditar;
        private PictureBox pictureBoxGuardar;
        private PictureBox pictureBoxEliminar;
        private PictureBox pictureBoxBuscar;
    }
}