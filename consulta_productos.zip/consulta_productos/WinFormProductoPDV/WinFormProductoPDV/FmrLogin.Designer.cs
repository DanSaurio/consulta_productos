﻿namespace WinFormProductoPDV
{
    partial class FmrLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FmrLogin));
            textousuario = new Label();
            textopassword = new Label();
            Usuariologin = new TextBox();
            Passwordlogin = new TextBox();
            btnAceptar = new Button();
            label1 = new Label();
            label2 = new Label();
            button1 = new Button();
            SuspendLayout();
            // 
            // textousuario
            // 
            textousuario.AutoSize = true;
            textousuario.BackColor = Color.Transparent;
            textousuario.FlatStyle = FlatStyle.Flat;
            textousuario.Font = new Font("Lucida Sans", 8.25F, FontStyle.Regular, GraphicsUnit.Point);
            textousuario.Location = new Point(62, 74);
            textousuario.Name = "textousuario";
            textousuario.Size = new Size(48, 14);
            textousuario.TabIndex = 0;
            textousuario.Text = "Usuario";
            // 
            // textopassword
            // 
            textopassword.AutoSize = true;
            textopassword.BackColor = Color.Transparent;
            textopassword.FlatStyle = FlatStyle.Flat;
            textopassword.Font = new Font("Lucida Sans", 9F, FontStyle.Regular, GraphicsUnit.Point);
            textopassword.Location = new Point(42, 213);
            textopassword.Name = "textopassword";
            textopassword.Size = new Size(73, 15);
            textopassword.TabIndex = 1;
            textopassword.Text = "Contraseña";
            // 
            // Usuariologin
            // 
            Usuariologin.Location = new Point(144, 74);
            Usuariologin.Name = "Usuariologin";
            Usuariologin.Size = new Size(318, 23);
            Usuariologin.TabIndex = 2;
            Usuariologin.TextChanged += Usuariologin_TextChanged;
            // 
            // Passwordlogin
            // 
            Passwordlogin.Location = new Point(144, 213);
            Passwordlogin.Name = "Passwordlogin";
            Passwordlogin.PasswordChar = '*';
            Passwordlogin.Size = new Size(318, 23);
            Passwordlogin.TabIndex = 3;
            Passwordlogin.TextChanged += Passwordlogin_TextChanged;
            // 
            // btnAceptar
            // 
            btnAceptar.Location = new Point(213, 267);
            btnAceptar.Name = "btnAceptar";
            btnAceptar.Size = new Size(75, 23);
            btnAceptar.TabIndex = 4;
            btnAceptar.Text = "Aceptar";
            btnAceptar.UseVisualStyleBackColor = true;
            btnAceptar.Click += btnAceptar_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.FlatStyle = FlatStyle.Flat;
            label1.Font = new Font("Lucida Sans Typewriter", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(236, 46);
            label1.Name = "label1";
            label1.Size = new Size(133, 13);
            label1.TabIndex = 5;
            label1.Text = "Ingrese Su Usuario";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.FlatStyle = FlatStyle.Flat;
            label2.Font = new Font("Lucida Sans", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.ControlText;
            label2.Location = new Point(236, 195);
            label2.Name = "label2";
            label2.Size = new Size(119, 15);
            label2.TabIndex = 6;
            label2.Text = "Ingrese Contraseña";
            // 
            // button1
            // 
            button1.Location = new Point(306, 267);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 7;
            button1.Text = "Cancelar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // FmrLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Aquamarine;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(584, 361);
            Controls.Add(button1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(btnAceptar);
            Controls.Add(Passwordlogin);
            Controls.Add(Usuariologin);
            Controls.Add(textopassword);
            Controls.Add(textousuario);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FmrLogin";
            Text = "Login";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label textousuario;
        private Label textopassword;
        private TextBox Usuariologin;
        private TextBox Passwordlogin;
        private Button btnAceptar;
        private Label label1;
        private Label label2;
        private Button button1;
    }
}