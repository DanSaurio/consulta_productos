﻿namespace WinFormProductoPDV
{
    partial class FrmCRUD
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCRUD));
            printPreviewDialog1 = new PrintPreviewDialog();
            panelPpal = new Panel();
            panel2 = new Panel();
            dGridProductos = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            Column6 = new DataGridViewTextBoxColumn();
            panel1 = new Panel();
            picBoxImagen = new PictureBox();
            iconPictureBoxImagen = new FontAwesome.Sharp.IconPictureBox();
            iconPicBoxSave = new FontAwesome.Sharp.IconPictureBox();
            iconPicBoxDelete = new FontAwesome.Sharp.IconPictureBox();
            iconPicBoxEdit = new FontAwesome.Sharp.IconPictureBox();
            iconPicBoxNuevo = new FontAwesome.Sharp.IconPictureBox();
            lblPrecio = new Label();
            txtPrecio = new TextBox();
            lblCodBarras = new Label();
            txtCodBarras = new TextBox();
            lblImagen = new Label();
            txtImagen = new TextBox();
            lblDescripcion = new Label();
            txtDescripcion = new TextBox();
            lblNombre = new Label();
            txtNombre = new TextBox();
            iconPicBoxBuscar = new FontAwesome.Sharp.IconPictureBox();
            txtBuscador = new TextBox();
            label1 = new Label();
            openFileDialog1 = new OpenFileDialog();
            panelPpal.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dGridProductos).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)picBoxImagen).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBoxImagen).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxSave).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxDelete).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxEdit).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxNuevo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxBuscar).BeginInit();
            SuspendLayout();
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // panelPpal
            // 
            panelPpal.BackColor = Color.Transparent;
            panelPpal.BorderStyle = BorderStyle.FixedSingle;
            panelPpal.Controls.Add(panel2);
            panelPpal.Controls.Add(panel1);
            panelPpal.Location = new Point(12, 12);
            panelPpal.Name = "panelPpal";
            panelPpal.Size = new Size(1142, 638);
            panelPpal.TabIndex = 0;
            // 
            // panel2
            // 
            panel2.BorderStyle = BorderStyle.Fixed3D;
            panel2.Controls.Add(dGridProductos);
            panel2.Location = new Point(15, 409);
            panel2.Name = "panel2";
            panel2.Size = new Size(1108, 212);
            panel2.TabIndex = 1;
            // 
            // dGridProductos
            // 
            dGridProductos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dGridProductos.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column4, Column3, Column5, Column6 });
            dGridProductos.Location = new Point(3, 3);
            dGridProductos.Name = "dGridProductos";
            dGridProductos.RowTemplate.Height = 25;
            dGridProductos.Size = new Size(1098, 426);
            dGridProductos.TabIndex = 0;
            dGridProductos.CellClick += dGridProductos_CellClick;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.Name = "Column1";
            // 
            // Column2
            // 
            Column2.HeaderText = "Nombre";
            Column2.Name = "Column2";
            // 
            // Column4
            // 
            Column4.HeaderText = "Código Barras";
            Column4.Name = "Column4";
            // 
            // Column3
            // 
            Column3.HeaderText = "Desc";
            Column3.Name = "Column3";
            // 
            // Column5
            // 
            Column5.HeaderText = "Precio";
            Column5.Name = "Column5";
            // 
            // Column6
            // 
            Column6.HeaderText = "IMagen";
            Column6.Name = "Column6";
            // 
            // panel1
            // 
            panel1.BorderStyle = BorderStyle.Fixed3D;
            panel1.Controls.Add(picBoxImagen);
            panel1.Controls.Add(iconPictureBoxImagen);
            panel1.Controls.Add(iconPicBoxSave);
            panel1.Controls.Add(iconPicBoxDelete);
            panel1.Controls.Add(iconPicBoxEdit);
            panel1.Controls.Add(iconPicBoxNuevo);
            panel1.Controls.Add(lblPrecio);
            panel1.Controls.Add(txtPrecio);
            panel1.Controls.Add(lblCodBarras);
            panel1.Controls.Add(txtCodBarras);
            panel1.Controls.Add(lblImagen);
            panel1.Controls.Add(txtImagen);
            panel1.Controls.Add(lblDescripcion);
            panel1.Controls.Add(txtDescripcion);
            panel1.Controls.Add(lblNombre);
            panel1.Controls.Add(txtNombre);
            panel1.Controls.Add(iconPicBoxBuscar);
            panel1.Controls.Add(txtBuscador);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(13, 23);
            panel1.Name = "panel1";
            panel1.Size = new Size(1108, 380);
            panel1.TabIndex = 0;
            // 
            // picBoxImagen
            // 
            picBoxImagen.BorderStyle = BorderStyle.FixedSingle;
            picBoxImagen.Location = new Point(780, 135);
            picBoxImagen.Name = "picBoxImagen";
            picBoxImagen.Size = new Size(273, 176);
            picBoxImagen.TabIndex = 18;
            picBoxImagen.TabStop = false;
            // 
            // iconPictureBoxImagen
            // 
            iconPictureBoxImagen.BackColor = Color.Transparent;
            iconPictureBoxImagen.BorderStyle = BorderStyle.FixedSingle;
            iconPictureBoxImagen.ForeColor = SystemColors.ControlText;
            iconPictureBoxImagen.IconChar = FontAwesome.Sharp.IconChar.None;
            iconPictureBoxImagen.IconColor = SystemColors.ControlText;
            iconPictureBoxImagen.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBoxImagen.IconSize = 39;
            iconPictureBoxImagen.Location = new Point(719, 272);
            iconPictureBoxImagen.Name = "iconPictureBoxImagen";
            iconPictureBoxImagen.Size = new Size(43, 39);
            iconPictureBoxImagen.TabIndex = 17;
            iconPictureBoxImagen.TabStop = false;
            iconPictureBoxImagen.Click += iconPictureBoxImagen_Click;
            // 
            // iconPicBoxSave
            // 
            iconPicBoxSave.BackColor = Color.Transparent;
            iconPicBoxSave.BackgroundImageLayout = ImageLayout.Stretch;
            iconPicBoxSave.BorderStyle = BorderStyle.FixedSingle;
            iconPicBoxSave.ForeColor = Color.Blue;
            iconPicBoxSave.IconChar = FontAwesome.Sharp.IconChar.FloppyDisk;
            iconPicBoxSave.IconColor = Color.Blue;
            iconPicBoxSave.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPicBoxSave.IconSize = 43;
            iconPicBoxSave.Location = new Point(936, 317);
            iconPicBoxSave.Name = "iconPicBoxSave";
            iconPicBoxSave.Size = new Size(45, 45);
            iconPicBoxSave.SizeMode = PictureBoxSizeMode.AutoSize;
            iconPicBoxSave.TabIndex = 16;
            iconPicBoxSave.TabStop = false;
            iconPicBoxSave.Click += iconPicBoxSave_Click;
            // 
            // iconPicBoxDelete
            // 
            iconPicBoxDelete.BackColor = Color.Transparent;
            iconPicBoxDelete.BackgroundImageLayout = ImageLayout.Stretch;
            iconPicBoxDelete.BorderStyle = BorderStyle.FixedSingle;
            iconPicBoxDelete.ForeColor = Color.Red;
            iconPicBoxDelete.IconChar = FontAwesome.Sharp.IconChar.Eraser;
            iconPicBoxDelete.IconColor = Color.Red;
            iconPicBoxDelete.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPicBoxDelete.IconSize = 43;
            iconPicBoxDelete.Location = new Point(1015, 317);
            iconPicBoxDelete.Name = "iconPicBoxDelete";
            iconPicBoxDelete.Size = new Size(45, 45);
            iconPicBoxDelete.SizeMode = PictureBoxSizeMode.AutoSize;
            iconPicBoxDelete.TabIndex = 15;
            iconPicBoxDelete.TabStop = false;
            iconPicBoxDelete.Click += iconPicBoxDelete_Click;
            // 
            // iconPicBoxEdit
            // 
            iconPicBoxEdit.BackColor = Color.Transparent;
            iconPicBoxEdit.BackgroundImageLayout = ImageLayout.Stretch;
            iconPicBoxEdit.BorderStyle = BorderStyle.FixedSingle;
            iconPicBoxEdit.ForeColor = Color.FromArgb(255, 192, 128);
            iconPicBoxEdit.IconChar = FontAwesome.Sharp.IconChar.Pen;
            iconPicBoxEdit.IconColor = Color.FromArgb(255, 192, 128);
            iconPicBoxEdit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPicBoxEdit.IconSize = 43;
            iconPicBoxEdit.Location = new Point(863, 317);
            iconPicBoxEdit.Name = "iconPicBoxEdit";
            iconPicBoxEdit.Size = new Size(45, 45);
            iconPicBoxEdit.SizeMode = PictureBoxSizeMode.AutoSize;
            iconPicBoxEdit.TabIndex = 14;
            iconPicBoxEdit.TabStop = false;
            // 
            // iconPicBoxNuevo
            // 
            iconPicBoxNuevo.BackColor = Color.Transparent;
            iconPicBoxNuevo.BackgroundImageLayout = ImageLayout.Stretch;
            iconPicBoxNuevo.BorderStyle = BorderStyle.FixedSingle;
            iconPicBoxNuevo.ForeColor = Color.SeaGreen;
            iconPicBoxNuevo.IconChar = FontAwesome.Sharp.IconChar.Plus;
            iconPicBoxNuevo.IconColor = Color.SeaGreen;
            iconPicBoxNuevo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPicBoxNuevo.IconSize = 43;
            iconPicBoxNuevo.Location = new Point(778, 317);
            iconPicBoxNuevo.Name = "iconPicBoxNuevo";
            iconPicBoxNuevo.Size = new Size(45, 45);
            iconPicBoxNuevo.SizeMode = PictureBoxSizeMode.AutoSize;
            iconPicBoxNuevo.TabIndex = 13;
            iconPicBoxNuevo.TabStop = false;
            iconPicBoxNuevo.Click += iconPicBoxNuevo_Click;
            // 
            // lblPrecio
            // 
            lblPrecio.AutoSize = true;
            lblPrecio.Font = new Font("Lucida Sans", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblPrecio.ForeColor = SystemColors.ControlLightLight;
            lblPrecio.Location = new Point(523, 233);
            lblPrecio.Name = "lblPrecio";
            lblPrecio.Size = new Size(93, 27);
            lblPrecio.TabIndex = 12;
            lblPrecio.Text = "Precio:";
            // 
            // txtPrecio
            // 
            txtPrecio.Enabled = false;
            txtPrecio.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            txtPrecio.Location = new Point(622, 226);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.Size = new Size(140, 39);
            txtPrecio.TabIndex = 11;
            // 
            // lblCodBarras
            // 
            lblCodBarras.AutoSize = true;
            lblCodBarras.Font = new Font("Lucida Sans", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblCodBarras.ForeColor = SystemColors.ControlLightLight;
            lblCodBarras.Location = new Point(-2, 235);
            lblCodBarras.Name = "lblCodBarras";
            lblCodBarras.Size = new Size(227, 27);
            lblCodBarras.TabIndex = 10;
            lblCodBarras.Text = "Código de Barras:";
            // 
            // txtCodBarras
            // 
            txtCodBarras.Enabled = false;
            txtCodBarras.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            txtCodBarras.Location = new Point(270, 227);
            txtCodBarras.Name = "txtCodBarras";
            txtCodBarras.Size = new Size(233, 39);
            txtCodBarras.TabIndex = 9;
            // 
            // lblImagen
            // 
            lblImagen.AutoSize = true;
            lblImagen.Font = new Font("Lucida Sans", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblImagen.ForeColor = SystemColors.ControlLightLight;
            lblImagen.Location = new Point(-2, 279);
            lblImagen.Name = "lblImagen";
            lblImagen.Size = new Size(110, 27);
            lblImagen.TabIndex = 8;
            lblImagen.Text = "Imagen:";
            // 
            // txtImagen
            // 
            txtImagen.Enabled = false;
            txtImagen.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            txtImagen.Location = new Point(270, 272);
            txtImagen.Name = "txtImagen";
            txtImagen.Size = new Size(443, 39);
            txtImagen.TabIndex = 7;
            txtImagen.TextChanged += txtImagen_TextChanged;
            // 
            // lblDescripcion
            // 
            lblDescripcion.AutoSize = true;
            lblDescripcion.Font = new Font("Lucida Sans", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblDescripcion.ForeColor = SystemColors.ControlLightLight;
            lblDescripcion.Location = new Point(-2, 193);
            lblDescripcion.Name = "lblDescripcion";
            lblDescripcion.Size = new Size(161, 27);
            lblDescripcion.TabIndex = 6;
            lblDescripcion.Text = "Descripción:";
            // 
            // txtDescripcion
            // 
            txtDescripcion.Enabled = false;
            txtDescripcion.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            txtDescripcion.Location = new Point(270, 181);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new Size(492, 39);
            txtDescripcion.TabIndex = 5;
            // 
            // lblNombre
            // 
            lblNombre.AutoSize = true;
            lblNombre.Font = new Font("Lucida Sans", 18F, FontStyle.Bold, GraphicsUnit.Point);
            lblNombre.ForeColor = SystemColors.ControlLightLight;
            lblNombre.Location = new Point(0, 141);
            lblNombre.Name = "lblNombre";
            lblNombre.Size = new Size(128, 27);
            lblNombre.TabIndex = 4;
            lblNombre.Text = "Producto:";
            // 
            // txtNombre
            // 
            txtNombre.Enabled = false;
            txtNombre.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            txtNombre.Location = new Point(269, 135);
            txtNombre.Name = "txtNombre";
            txtNombre.Size = new Size(493, 39);
            txtNombre.TabIndex = 3;
            // 
            // iconPicBoxBuscar
            // 
            iconPicBoxBuscar.BackColor = Color.Transparent;
            iconPicBoxBuscar.BackgroundImageLayout = ImageLayout.Stretch;
            iconPicBoxBuscar.ForeColor = Color.Blue;
            iconPicBoxBuscar.IconChar = FontAwesome.Sharp.IconChar.Searchengin;
            iconPicBoxBuscar.IconColor = Color.Blue;
            iconPicBoxBuscar.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPicBoxBuscar.IconSize = 39;
            iconPicBoxBuscar.Location = new Point(1062, 51);
            iconPicBoxBuscar.Name = "iconPicBoxBuscar";
            iconPicBoxBuscar.Size = new Size(39, 39);
            iconPicBoxBuscar.SizeMode = PictureBoxSizeMode.AutoSize;
            iconPicBoxBuscar.TabIndex = 2;
            iconPicBoxBuscar.TabStop = false;
            iconPicBoxBuscar.Click += iconPicBoxBuscar_Click;
            // 
            // txtBuscador
            // 
            txtBuscador.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point);
            txtBuscador.Location = new Point(21, 51);
            txtBuscador.Name = "txtBuscador";
            txtBuscador.Size = new Size(1035, 39);
            txtBuscador.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Lucida Sans", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.ControlLightLight;
            label1.Location = new Point(21, 11);
            label1.Name = "label1";
            label1.Size = new Size(234, 27);
            label1.TabIndex = 0;
            label1.Text = "Producto a Buscar";
            label1.Click += label1_Click;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            openFileDialog1.FileOk += openFileDialog1_FileOk;
            // 
            // FrmCRUD
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1180, 682);
            Controls.Add(panelPpal);
            Name = "FrmCRUD";
            Text = "Catálogo de Productos";
            Load += FrmCRUD_Load;
            panelPpal.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dGridProductos).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)picBoxImagen).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBoxImagen).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxSave).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxDelete).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxEdit).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxNuevo).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPicBoxBuscar).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PrintPreviewDialog printPreviewDialog1;
        private Panel panelPpal;
        private Panel panel2;
        private DataGridView dGridProductos;
        private Panel panel1;
        private TextBox txtBuscador;
        private Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPicBoxBuscar;
        private TextBox txtNombre;
        private Label lblPrecio;
        private TextBox txtPrecio;
        private Label lblCodBarras;
        private TextBox txtCodBarras;
        private Label lblImagen;
        private TextBox txtImagen;
        private Label lblDescripcion;
        private TextBox txtDescripcion;
        private Label lblNombre;
        private FontAwesome.Sharp.IconPictureBox iconPicBoxSave;
        private FontAwesome.Sharp.IconPictureBox iconPicBoxDelete;
        private FontAwesome.Sharp.IconPictureBox iconPicBoxEdit;
        private FontAwesome.Sharp.IconPictureBox iconPicBoxNuevo;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column5;
        private DataGridViewTextBoxColumn Column6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBoxImagen;
        private OpenFileDialog openFileDialog1;
        private PictureBox picBoxImagen;
    }
}