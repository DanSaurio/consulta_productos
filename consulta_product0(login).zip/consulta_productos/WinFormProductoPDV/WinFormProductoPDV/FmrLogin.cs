﻿using FontAwesome.Sharp;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormProductoPDV
{
    public partial class FmrLogin : Form
    {
            int id = 0;
            //vars de BD
            MySqlConnection con = new MySqlConnection("Server=localhost;Database=productos_pdv;Uid=root;Pwd=;");
            MySqlCommand comando = new MySqlCommand("SELECT * FROM usuarios");
            MySqlDataReader dr;
        public FmrLogin()
        {

            {
                InitializeComponent();
            }
         
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            //consultamos la BD para poner los registros actuales de
            if (con.State == ConnectionState.Closed)//1.conectarse

                con.Open();
            //2. crear el command (SELECT *)
            comando = new MySqlCommand("SELECT * FROM usuarios WHERE nombre='"
                +Usuariologin.Text+"' AND password='"+Passwordlogin.Text+"'");
            //3. asociar la CONEXION al COMMAND
            comando.Connection = con;
            //4. ejecutar el COMMAND (dataReader = executeReader())
            dr = comando.ExecuteReader();
            //5. Mostrarlos en el GridView
            if (dr.HasRows)
            {
                FrmCRUD fmrCrud= new FrmCRUD();
                this.Hide();
                fmrCrud.Show();
                
            }
            else
            {
                MessageBox.Show("No hay USUARIOS registrados aún...");
            }
            //6. cerrar conexion TE DIJE!!!!
            con.Close();
        }

        private void Usuariologin_TextChanged(object sender, EventArgs e)
        {

        }

        private void Passwordlogin_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Usuariologin.Clear  ();
            Passwordlogin.Clear ();
        }
    }
}
